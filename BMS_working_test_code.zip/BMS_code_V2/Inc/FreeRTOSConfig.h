#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

/* FreeRTOS settings for the bench tests on the STM32G474 (Cortex-M4F,
 * internal 16 MHz HSI clock). One test task runs at a time (see main.c).
 *
 * The ones worth knowing:
 *   configCPU_CLOCK_HZ   -- must match the real core clock (SystemInit);
 *                           tick timing and the fast poll's microsecond
 *                           timer both depend on it.
 *   configTICK_RATE_HZ   -- 1 kHz, so vTaskDelay resolves 1 ms. A
 *                           vTaskDelay(2 ms) can wake after just over 1 ms
 *                           -- ask for one tick more than you need.
 *   configTOTAL_HEAP_SIZE -- task stacks come from this 8 KB heap.
 *   configCHECK_FOR_STACK_OVERFLOW / configUSE_MALLOC_FAILED_HOOK -- both
 *                           on, so those bugs light the fault LED instead
 *                           of corrupting memory silently. Keep them on. */

#define configUSE_PREEMPTION                   1
#define configUSE_IDLE_HOOK                    0
#define configUSE_TICK_HOOK                    0
#define configCPU_CLOCK_HZ                     16000000UL
#define configTICK_RATE_HZ                     1000
#define configMAX_PRIORITIES                   5
#define configMINIMAL_STACK_SIZE               128
#define configTOTAL_HEAP_SIZE                  (8 * 1024)
#define configMAX_TASK_NAME_LEN                16
#define configUSE_16_BIT_TICKS                 0
#define configIDLE_SHOULD_YIELD                1
#define configUSE_MUTEXES                      1
#define configUSE_TASK_NOTIFICATIONS           1
#define configUSE_COUNTING_SEMAPHORES          0
#define configQUEUE_REGISTRY_SIZE              0
#define configUSE_TIMERS                       0

#define configSUPPORT_DYNAMIC_ALLOCATION       1
#define configSUPPORT_STATIC_ALLOCATION        0

#define configCHECK_FOR_STACK_OVERFLOW         2
#define configUSE_MALLOC_FAILED_HOOK           1

/* A failed assert halts with the fault LED on (Src/fault.c). */
void fault_halt(void) __attribute__((noreturn));
#define configASSERT( x )                      if ((x) == 0) { fault_halt(); }

/* freertos_setup.c installs SVC_Handler/PendSV_Handler as wrappers that
 * tail-branch into vPortSVCHandler/xPortPendSVHandler ("indirect routing",
 * since the vector table uses CMSIS names the port doesn't know about).
 * The port's default startup check expects the vector table to name the
 * port functions directly ("direct routing") and traps in configASSERT
 * otherwise -- FreeRTOS's own docs say indirect-routing apps must disable
 * this check. */
#define configCHECK_HANDLER_INSTALLATION       0

/* Cortex-M4 on STM32 implements 4 priority bits (16 preemption levels). */
#define configPRIO_BITS                        4
#define configKERNEL_INTERRUPT_PRIORITY        ( 15 << (8 - configPRIO_BITS) )
#define configMAX_SYSCALL_INTERRUPT_PRIORITY   ( 5  << (8 - configPRIO_BITS) )
#define configLIBRARY_LOWEST_INTERRUPT_PRIORITY    15
#define configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY 5

#define INCLUDE_vTaskDelay                     1
#define INCLUDE_vTaskDelayUntil                1
#define INCLUDE_vTaskSuspend                   1
#define INCLUDE_xTaskGetSchedulerState         1
#define INCLUDE_uxTaskPriorityGet              1

#endif /* FREERTOS_CONFIG_H */
