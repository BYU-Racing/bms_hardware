#!/usr/bin/env bash
# ESP-IDF-style wrapper: ./bms.sh build flash
#
# Runs the Windows-native STM32Cube toolchain (arm-none-eabi-gcc, cmake,
# ninja, STM32_Programmer_CLI) from WSL via interop. These run as real
# Windows processes, so USB/ST-LINK access just works -- no usbipd needed.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PRESET="${PRESET:-Debug}"
ELF="build/$PRESET/BMS_code_V2.elf"
SWO_CPU_MHZ=16  # keep in sync with configCPU_CLOCK_HZ in Inc/FreeRTOSConfig.h
BUNDLES="/mnt/c/Users/rugby/AppData/Local/stm32cube/bundles"

# Bundle versions get updated by the STM32 VS Code extension over time, so
# pick whatever's newest under each bundle instead of hardcoding a version.
resolve_bundle_bin() {
    local name="$1" dir
    dir=$(ls -d "$BUNDLES/$name"/*/bin 2>/dev/null | sort -V | tail -n1)
    if [ -z "$dir" ]; then
        echo "error: no '$name' bundle found under $BUNDLES" >&2
        echo "       (open the STM32 extension in VS Code once to let it download tools)" >&2
        exit 1
    fi
    echo "$dir"
}

GCC_BIN="$(resolve_bundle_bin gnu-tools-for-stm32)"
NINJA_BIN="$(resolve_bundle_bin ninja)"
CMAKE_BIN="$(resolve_bundle_bin cmake)"
PROGRAMMER_CLI="$(resolve_bundle_bin programmer)/STM32_Programmer_CLI.exe"
CMAKE_EXE="$CMAKE_BIN/cmake.exe"
GDBSERVER_CLI="$(resolve_bundle_bin stlink-gdbserver)/ST-LINK_gdbserver.exe"
GDB_CLI="$(resolve_bundle_bin gnu-gdb-for-stm32)/arm-none-eabi-gdb.exe"

# cmake.exe is itself a Windows process. When it searches PATH internally
# (to find ninja.exe / arm-none-eabi-gcc.exe), it needs a Windows-style,
# semicolon-separated PATH -- WSL does NOT translate the *contents* of a
# PATH string when handing it to a spawned Windows process, so a plain
# export of our /mnt/c/... bash PATH is invisible to cmake.exe's own
# child-process lookups. Build a Windows-style PATH just for that.
WIN_TOOL_PATH="$(wslpath -w "$GCC_BIN");$(wslpath -w "$NINJA_BIN");$(wslpath -w "$CMAKE_BIN")"

# WSL does not forward bash's PATH into an interop-launched Windows process
# at all unless the variable is explicitly listed in WSLENV -- without this,
# cmake.exe silently falls back to the ordinary Windows user PATH and can't
# find ninja.exe / arm-none-eabi-gcc.exe. "/w" means "already a single
# Windows-style path, pass through as-is".
export WSLENV="PATH/w:${WSLENV:-}"

cmake_win() {
    PATH="$WIN_TOOL_PATH" "$CMAKE_EXE" "$@"
}

cmd_configure() {
    echo "==> Configuring ($PRESET)"
    # CMAKE_ARGS passes extra -D options, e.g.
    #   CMAKE_ARGS=-DBMS_PRINTF_SWO=OFF ./bms.sh configure build
    # shellcheck disable=SC2086
    cmake_win --preset "$PRESET" ${CMAKE_ARGS:-}
}

cmd_build() {
    [ -d "build/$PRESET" ] || cmd_configure
    echo "==> Building ($PRESET)"
    cmake_win --build --preset "$PRESET"
}

cmd_flash() {
    [ -f "$ELF" ] || { echo "error: $ELF not built yet -- run '$0 build' first" >&2; exit 1; }
    echo "==> Flashing $ELF over SWD"
    "$PROGRAMMER_CLI" -c port=SWD mode=UR freq=400 -w "$ELF" -v -rst
}

cmd_clean() {
    echo "==> Removing build/$PRESET"
    rm -rf "build/$PRESET"
}

cmd_monitor() {
    echo "==> Starting SWO monitor (PB3) -- printf output appears below (Ctrl-C to stop)"

    # Hot-plug (no reset under the probe), then reset the target so output
    # starts from boot, then start SWV reception on ITM port 0. freq= must
    # be the CPU clock in MHz (configCPU_CLOCK_HZ in Inc/FreeRTOSConfig.h)
    # -- the probe derives the SWO baud rate from it.
    "$PROGRAMMER_CLI" -c port=SWD mode=HOTPLUG freq=400 -rst \
        -startswv freq="$SWO_CPU_MHZ" portnumber=0
}

cmd_semihost() {
    [ -f "$ELF" ] || { echo "error: $ELF not built yet -- run '$0 build' first" >&2; exit 1; }
    echo "==> Starting semihosting monitor over SWD -- printf output appears below (Ctrl-C to stop)"
    echo "    (needs a semihosting build: configure with -DBMS_PRINTF_SWO=OFF)"

    local port=61234
    # -cp needs a Windows-style path -- gdbserver.exe is a Windows process
    # and (unlike the plain positional file args below) does not get this
    # argument auto-translated from WSL's /mnt/c form.
    local programmer_dir
    programmer_dir="$(wslpath -w "$(dirname "$PROGRAMMER_CLI")")"

    # -k --halt: reset the target under debug control and halt it, so we
    # always start from a clean reset instead of whatever state a previous
    # standalone run (which can hang/fault on the first printf with no
    # debugger attached) left it in. -d forces SWD (this probe defaults to
    # JTAG otherwise). --semihosting terminal makes the gdbserver print
    # semihosted output straight to its own stdout.
    "$GDBSERVER_CLI" --semihosting terminal -d -k --halt --frequency 400 \
        -p "$port" -cp "$programmer_dir" &
    # Expand the PID now: the EXIT trap fires after this function returns,
    # when a `local` would already be gone (and `set -u` would abort).
    local gdbserver_pid=$!
    trap "kill $gdbserver_pid 2>/dev/null" EXIT

    sleep 2

    # gdb must stay attached and blocked in `continue` for the gdbserver to
    # keep servicing semihosting calls -- it re-halts the target once the
    # remote connection drops.
    "$GDB_CLI" -q --batch \
        -ex "target extended-remote localhost:$port" \
        -ex "continue" \
        "$ELF"
}

cmd_probe() {
    echo "==> Listing connected debug probes / DFU / UART interfaces"
    "$PROGRAMMER_CLI" -l
}

usage() {
    cat <<EOF
Usage: $0 <command> [command...]

Commands:
  build      Configure (if needed) and compile
  flash      Flash the last build over SWD (ST-LINK must be connected)
  monitor    Reset the target and stream printf over SWO (PB3) to this terminal
  semihost   Attach over SWD and stream printf via semihosting (needs a
             -DBMS_PRINTF_SWO=OFF build)
  probe      List connected ST-LINK/J-Link/DFU/UART interfaces
  clean      Remove build/$PRESET
  configure  Force a fresh CMake configure

Commands run in the order given, e.g.:
  $0 build flash

Set PRESET=Release to build/flash the Release config instead of Debug.
EOF
}

[ $# -eq 0 ] && { usage; exit 1; }

for arg in "$@"; do
    case "$arg" in
        build) cmd_build ;;
        flash) cmd_flash ;;
        monitor) cmd_monitor ;;
        semihost) cmd_semihost ;;
        probe) cmd_probe ;;
        clean) cmd_clean ;;
        configure) cmd_configure ;;
        -h|--help) usage; exit 0 ;;
        *) echo "error: unknown command '$arg'" >&2; usage; exit 1 ;;
    esac
done
