/**
 * All the "make FreeRTOS actually boot on this chip" plumbing lives here,
 * separate from application code (led.c, etc). None of this is called
 * directly by main.c -- the startup file's vector table and the FreeRTOS
 * kernel find these functions by name. You shouldn't need to touch this
 * file when adding new tasks; add hooks below only if the kernel needs one
 * you haven't provided yet (the linker error will say which).
 */

#include "FreeRTOS.h"
#include "task.h"
#include "fault.h"

/* -------------------------------------------------------------------------
 * System init
 * ---------------------------------------------------------------------- */

/* Startup code calls this before main(); must exist or it crashes on boot.
 * Empty is fine here since we run on the default 16 MHz HSI clock -- add
 * PLL/clock-tree setup here if a task ever needs a faster core clock.
 * TIP: the fast poll benchmark found the CPU (not the link) is the main
 * speed limit at 16 MHz; the G474 runs up to 170 MHz. If you change the
 * clock, also update configCPU_CLOCK_HZ (FreeRTOSConfig.h), the SPI
 * prescaler (isospi.c, keep SCK <= 1 MHz), and SWO_CPU_MHZ (bms.sh). */
void SystemInit(void) {}

/* -------------------------------------------------------------------------
 * Exception handlers required by the FreeRTOS Cortex-M4F port
 * ---------------------------------------------------------------------- */

/* The port implements these under its own names. The vector table
 * (startup_stm32g474xx.S) looks for the standard CMSIS names, so route
 * those straight into the port with a tail branch -- "b" (not "bl") so
 * LR/EXC_RETURN reaches the naked handlers untouched. */
extern void vPortSVCHandler(void);
extern void xPortPendSVHandler(void);
extern void xPortSysTickHandler(void);

void SVC_Handler(void) __attribute__((naked));
void SVC_Handler(void)
{
    __asm volatile("b vPortSVCHandler");
}

void PendSV_Handler(void) __attribute__((naked));
void PendSV_Handler(void)
{
    __asm volatile("b xPortPendSVHandler");
}

void SysTick_Handler(void)
{
    xPortSysTickHandler();
}

/* -------------------------------------------------------------------------
 * FreeRTOS hooks (enabled/disabled via Inc/FreeRTOSConfig.h)
 * ---------------------------------------------------------------------- */

/* Required because configCHECK_FOR_STACK_OVERFLOW is enabled in FreeRTOSConfig.h. */
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)xTask;
    (void)pcTaskName;
    fault_halt(); /* a debugger can still read xTask/pcTaskName from the caller's frame */
}

/* Required because configUSE_MALLOC_FAILED_HOOK is enabled -- the FreeRTOS
 * heap (configTOTAL_HEAP_SIZE) ran out, e.g. creating a task. */
void vApplicationMallocFailedHook(void)
{
    fault_halt();
}
