/*
 * fault.c -- one place every "this should never happen" path ends up. See
 * fault.h.
 *
 * WHY: by default an STM32 that crashes just sits in an infinite loop with
 * no sign of life -- indistinguishable from "busy". Routing every fault to
 * one function that lights a dedicated LED makes a crash visible on the
 * bench, and a debugger attached afterwards finds the core parked here.
 * In the real BMS this is also where you'd force the system into a SAFE
 * state (open the AIRs / signal a BMS fault) -- a crashed BMS must never
 * look healthy.
 */

#include "hw.h"
#include "led.h"
#include "fault.h"

void fault_halt(void)
{
    /* Mask interrupts first: this stops the RTOS scheduler and every ISR,
     * so nothing else runs (or overwrites the evidence) from here on. */
    __asm volatile ("cpsid i" ::: "memory");

    led_set(HW_LED_ACTIVE, 0);
    led_set(HW_LED_FAULT, 1);

    for (;;) {}
}

/* The startup file declares these handlers "weak", pointing at a bare
 * infinite loop. Defining them here overrides that, so every CPU fault
 * lights the fault LED. Handlers run on the main stack, so they still work
 * when a task has trashed its own stack.
 * TIP: in a debugger, the fault status registers (CFSR at 0xE000ED28,
 * HFSR, MMFAR, BFAR) tell you WHY it faulted -- worth a helper that saves
 * them before halting. */
void NMI_Handler(void)        { fault_halt(); }
void HardFault_Handler(void)  { fault_halt(); }
void MemManage_Handler(void)  { fault_halt(); }
void BusFault_Handler(void)   { fault_halt(); }
void UsageFault_Handler(void) { fault_halt(); }
