# BMS bring-up firmware (2027 design) — reference code

Bench test firmware for the 2027 BMS. The **master board** (STM32G474) talks over **isoSPI** (LTC6820) to the **slave boards** (LTC6811-1 + 16 thermistors through two TMUX1308 muxes). It measures cell voltages and temperatures and prints them to your laptop.

**This is reference code, not the final BMS.** Read it to see what works and why, then write your own. The comments in each file explain the reasoning and include "TIP" notes for the rewrite.

## Values marked `RUGBY INPUT`

Pins, wiring, part numbers and resistor values were supplied by Rugby from the schematic, datasheets and bench measurements. Each one is tagged **`RUGBY INPUT`** in a comment. They describe the hardware rather than firmware choices, so check each one against **your** board revision before trusting it:

```
grep -rn "RUGBY INPUT" Inc Src
```

Most of them are in [Inc/hw.h](Inc/hw.h). That file is meant to be the only place a board revision should require a firmware change.

## Quick start

Everything runs from the VS Code terminal (Windows, through WSL):

| Command | What it does |
|---|---|
| `wsl ./bms.sh build` | Configure (first time) and compile |
| `wsl ./bms.sh flash` | Flash over SWD (ST-LINK V3 + Tag-Connect) |
| `wsl ./bms.sh monitor` | Reset the board and stream `printf` output (SWO, pin PB3) |
| `wsl ./bms.sh semihost` | The same over the debugger, when SWO isn't working (needs a semihosting build; see [Inc/semihosting.h](Inc/semihosting.h)) |
| `wsl ./bms.sh probe` | List connected ST-LINKs |
| `wsl ./bms.sh build flash monitor` | The usual loop |

`monitor`: press **E** to exit. Pressing reset or unplugging the ST-LINK is always safe.

## The tests (select one with `TEST_TASK` in [Src/main.c](Src/main.c))

| # | Test | Use it to | File |
|---|---|---|---|
| 2 | **isoSPI link test** | Prove communication works. **Run this first** on any new board. | [Src/isospi_test.c](Src/isospi_test.c) |
| 3 | **Board check** (default) | Check a slave board: every cell, the stack total, every thermistor in °C. Samples, then sleeps. | [Src/board_check.c](Src/board_check.c) |
| 0 | **Detailed report** | Debug: raw mV, thermistor resistance, VREF2, sleep/wake and mux checks, multimeter "hold" mode | [Src/cell_test.c](Src/cell_test.c) |
| 1 | **Fast poll** | Measure how fast the link can go, to design the real polling loop | [Src/fast_poll.c](Src/fast_poll.c) |

Board check output (one slave, 10k test resistors on TH6 and TH8):
```
=== Board check 1 ===
 Slave 0
  C0  3.4011 V   TH0  NOT CONNECTED
  ...
  C6  3.4028 V   TH6  24.3 C
  ...
  Stack 40.979 V
  TH12 NOT CONNECTED   TH13 NOT CONNECTED   TH14 NOT CONNECTED   TH15 NOT CONNECTED
```

## File map

| File | Purpose |
|---|---|
| [Inc/hw.h](Inc/hw.h) | **Board description:** pins, LED meanings, chain length, mux wiring, thermistor map, pull-up value |
| [Inc/isospi.h](Inc/isospi.h), [Src/isospi.c](Src/isospi.c) | **LTC6820/LTC6811 driver:** SPI setup, wake-up, PEC (CRC), command/read/write frames. Start reading here. |
| [Src/thermistor.c](Src/thermistor.c) | Divider voltage → resistance → °C (Vishay curve) |
| [Src/gpio.c](Src/gpio.c), [Src/led.c](Src/led.c) | Register-level GPIO, status LEDs |
| [Src/fault.c](Src/fault.c) | Every crash or assert path halts with LED7 on |
| [Src/swo.c](Src/swo.c), [Src/semihosting.c](Src/semihosting.c) | Where `printf` goes (only one is built; CMake option `BMS_PRINTF_SWO`) |
| [Src/System/freertos_setup.c](Src/System/freertos_setup.c), [Inc/FreeRTOSConfig.h](Inc/FreeRTOSConfig.h) | FreeRTOS plumbing |
| [bms.sh](bms.sh), [CMakeLists.txt](CMakeLists.txt) | Build, flash and monitor scripts |

LEDs: **LED1** is on while measuring. **LED7** is the fault LED: on for one cycle after a communication error, **solid** if the program has halted.

## Bring-up notes (problems we already hit)

Each of these cost real time. Check them first on a new board.

1. **Every read returns `FF FF FF…`:** nothing is answering. In the order we found the causes:
   - **Wrong pins in `hw.h`.** SCK was set to PB13 instead of **PF1**, and CS to PB12 instead of **PB6**. Check all four isoSPI pins against the schematic.
   - **SPI mode doesn't match the LTC6820's POL/PHA straps.** They're tied to GND on our board, so the firmware uses SPI mode 0.
   - The slave's LTC6811 isn't powered (it needs the cell stack, ~11 V or more) or isn't awake.

   The link test prints the raw MOSI/MISO bytes, and "MISO low this run: no" means not a single bit came back.
2. **Cells read about 10 % low, and VREF2 reads ~2.89 V instead of 3.00 V:** **VREF1 and VREF2 were shorted** on the slave board. VREF1 is the ADC's reference. After the fix, the stack read 40.98 V against a 41 V supply.
3. **10k test resistors read 41–48 °C instead of 25 °C:** the firmware's **pull-up value** didn't match the part fitted (22k). Debug the resistance first (the detailed report prints it), then the temperature.
4. **A thermistor shows up on the "wrong" channel:** the detailed report measures the mux select lines (GPIO3/4/5) during every conversion and flags a mismatch, which separates firmware problems from board routing.
5. **Writes aren't acknowledged:** one mux-select write right after a wake went missing. The tests read the config back and retry.
6. **Sleep and wake:** the LTC6811 sleeps about 2 s after the last command, and its config resets. The isoSPI port idles after ~5 ms. Call `isospi_wakeup()` before talking after a pause, and wait ~1 s after waking before trusting thermistor readings (VREF2 needs to settle).
7. **SWO goes blank while the board is clearly running:** it's the Tag-Connect's SWO pin losing contact. Reseat or clip it, or use semihosting.
8. **The ST-LINK drops off USB** (`DEV_USB_COMM_ERR`, "No debug probe detected"): use a short, known-good cable straight into the laptop. "No STM32 target found" or `0.00V`, on the other hand, means the Tag-Connect or the board's power.

## Measured performance (1 slave board, 16 MHz CPU, 500 kHz SPI)

| Strategy | Cells | All 16 thermistors |
|---|---|---|
| Everything every scan, 7 kHz | 26.7 /s | 26.7 /s |
| **Round-robin**, 7 kHz (cells + 1 mux channel per scan) | **144 /s** | **18 /s** |
| Round-robin, 27 kHz | 195 /s | 24 /s |

Most of each scan is communication overhead at 16 MHz rather than conversion time. Running the CPU at 170 MHz, SPI at 1 MHz and a lookup-table PEC are the ways to speed it up, and they matter most with 9 boards. Details are in [Src/fast_poll.c](Src/fast_poll.c).

## Not done yet

- **Cell balancing.** External MOSFETs and 33 Ω resistors on the slave. A first test showed no current on the ammeter and was stopped before it was diagnosed. Check the S-pin → MOSFET gate drive. DTEN is tied low, so the LTC6811's ~2 s watchdog always turns balancing off if communication stops; keep that.
- **Running all 9 slave boards together.** Set `HW_ISOSPI_DEVICE_COUNT`. The write order through the chain is handled in the driver (see `isospi_write_group`), but it has only been tested with one board.
- **Clock speed-up** (170 MHz PLL) and a 1 MHz isoSPI clock.
- **Hardware notes for the next revision:**
  - a pull-up on the LTC6820 CS line
  - PB8 (BOOT0) is held high, which can stop the firmware starting without the debugger connected
  - the linker script assumes 512 KB of flash, but the chip reports 128 KB
