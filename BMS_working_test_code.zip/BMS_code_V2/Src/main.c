/*
 * main.c -- picks which bench test runs.
 *
 * This firmware is a set of bring-up/verification tests, not the final BMS
 * application. Each test is one FreeRTOS task that owns the isoSPI link,
 * so exactly one runs at a time. Change TEST_TASK, then
 * `wsl ./bms.sh build flash monitor`.
 *
 * Suggested order on a new board:
 *   2 (link test) -> 3 (board check) -> 0 (detailed report, if anything in
 *   the board check looks wrong) -> 1 (speed, when designing the real loop).
 */

#include "FreeRTOS.h"
#include "task.h"
#include "led.h"
#include "fault.h"
#include "cell_test.h"
#include "fast_poll.h"
#include "board_check.h"
#include "isospi_test.h"

/* Which test runs:
 *   0 = cell_test_task    detailed debug report (raw mV, resistances, VREF2,
 *                         sleep/wake check, mux check), sleeps between readings
 *   1 = fast_poll_task    everything back to back, prints scan rates
 *   2 = isospi_test_task  config write/read link check -- run this first
 *   3 = board_check_task  compact cells + temps per slave, sleeps between */
#define TEST_TASK 3

int main(void)
{
    /* First thing, so every LED starts off and fault_halt() can light the
     * fault LED no matter what fails afterwards. */
    led_init();

#if TEST_TASK == 1
    TaskFunction_t task = fast_poll_task;
#elif TEST_TASK == 2
    TaskFunction_t task = isospi_test_task;
#elif TEST_TASK == 3
    TaskFunction_t task = board_check_task;
#else
    TaskFunction_t task = cell_test_task;
#endif

    /* Stack is in WORDS (4 bytes each): 768 words = 3 KB. The tests format
     * reports with snprintf a few calls deep, which needs room. If a task
     * overflows, the stack-overflow hook halts with the fault LED on --
     * that's the first thing to suspect if LED7 lights after a change.
     * TIP: big buffers in these tests are `static` for the same reason. */
    if (xTaskCreate(task, "test", 768, NULL, 1, NULL) != pdPASS)
    {
        fault_halt();
    }

    /* Hands the CPU to FreeRTOS; never returns while things are healthy. */
    vTaskStartScheduler();

    fault_halt(); /* only reached if the scheduler fails to start (e.g. out of heap) */
}
